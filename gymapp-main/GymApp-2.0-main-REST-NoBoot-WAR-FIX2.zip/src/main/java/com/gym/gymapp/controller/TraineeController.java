package com.gym.gymapp.controller;

import com.gym.gymapp.dto.RegistrationDtos.*;
import com.gym.gymapp.facade.GymFacade;
import com.gym.gymapp.model.Trainee;
import com.gym.gymapp.model.Trainer;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Api(tags = "Trainees")
@RestController
@RequestMapping("/api/trainees")
public class TraineeController {
    private final GymFacade facade;
    public TraineeController(GymFacade facade) { this.facade = facade; }

    @ApiOperation("Trainee registration")
    @PostMapping
    public ResponseEntity<CredentialsResp> register(@Valid @RequestBody TraineeRegisterReq req){
        var created = facade.createTraineeProfile(req.firstName, req.lastName, true, req.dateOfBirth, req.address);
        return ResponseEntity.ok(new CredentialsResp(created.user().getUsername(), created.rawPassword()));
    }

    @ApiOperation("Get trainee profile")
    @GetMapping("/{username}")
    public ResponseEntity<Trainee> profile(@PathVariable String username,
                                           @RequestParam String authUser,
                                           @RequestParam String authPass){
        return ResponseEntity.ok(facade.getTraineeProfile(authUser, authPass, username));
    }

    @ApiOperation("Update trainee profile")
    @PutMapping
    public ResponseEntity<Trainee> update(@Valid @RequestBody UpdateTraineeReq req,
                                          @RequestParam String authUser, @RequestParam String authPass){
        Trainee t = facade.updateTraineeProfile(authUser, authPass, req.username, req.dateOfBirth, req.address);
        if (req.isActive != null) {
            facade.setTraineeActive(authUser, authPass, req.username, req.isActive);
            t.getUser().setIsActive(req.isActive);
        }
        return ResponseEntity.ok(t);
    }

    @ApiOperation("Delete trainee profile")
    @DeleteMapping("/{username}")
    public ResponseEntity<Void> delete(@PathVariable String username,
                                       @RequestParam String authUser, @RequestParam String authPass){
        facade.deleteTraineeByUsername(authUser, authPass, username);
        return ResponseEntity.ok().build();
    }

    @ApiOperation("Active trainers not assigned to trainee")
    @GetMapping("/{username}/trainers/available")
    public ResponseEntity<List<Trainer>> available(@PathVariable String username,
                                                   @RequestParam String authUser, @RequestParam String authPass){
        return ResponseEntity.ok(facade.listActiveNotAssignedTrainers(authUser, authPass, username));
    }

    @ApiOperation("Update trainee's trainer list (idempotent)")
    @PutMapping("/{username}/trainers")
    public ResponseEntity<Map<String, Object>> updateTrainers(@PathVariable String username,
                                                              @Valid @RequestBody UpdateTraineeTrainersReq req,
                                                              @RequestParam String authUser, @RequestParam String authPass){
        if (!username.equalsIgnoreCase(req.traineeUsername)) {
            throw new IllegalArgumentException("Path username and body traineeUsername must match");
        }
        facade.updateTraineeTrainers(authUser, authPass, req.traineeUsername, req.trainers);
        return ResponseEntity.ok(Map.of("updated", req.trainers.size()));
    }
}
