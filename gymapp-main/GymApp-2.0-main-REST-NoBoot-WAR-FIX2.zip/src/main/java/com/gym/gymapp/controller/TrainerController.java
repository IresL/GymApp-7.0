package com.gym.gymapp.controller;

import com.gym.gymapp.dto.RegistrationDtos.*;
import com.gym.gymapp.facade.GymFacade;
import com.gym.gymapp.model.Trainer;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Api(tags = "Trainers")
@RestController
@RequestMapping("/api/trainers")
public class TrainerController {
    private final GymFacade facade;
    public TrainerController(GymFacade facade) { this.facade = facade; }

    @ApiOperation("Trainer registration")
    @PostMapping
    public ResponseEntity<CredentialsResp> register(@Valid @RequestBody TrainerRegisterReq req){
        var created = facade.createTrainerProfile(req.firstName, req.lastName, true, req.specialization);
        return ResponseEntity.ok(new CredentialsResp(created.user().getUsername(), created.rawPassword()));
    }

    @ApiOperation("Get trainer profile")
    @GetMapping("/{username}")
    public ResponseEntity<Trainer> profile(@PathVariable String username,
                                           @RequestParam String authUser, @RequestParam String authPass){
        return ResponseEntity.ok(facade.getTrainerProfile(authUser, authPass, username));
    }

    @ApiOperation("Update trainer profile (specialization is read-only)")
    @PutMapping
    public ResponseEntity<Trainer> update(@Valid @RequestBody UpdateTrainerReq req,
                                          @RequestParam String authUser, @RequestParam String authPass){
        Trainer t = facade.updateTrainerProfile(authUser, authPass, req.username, req.firstName, req.lastName);
        if (req.isActive != null) {
            facade.setTrainerActive(authUser, authPass, req.username, req.isActive);
            t.getUser().setIsActive(req.isActive);
        }
        return ResponseEntity.ok(t);
    }
}
