package com.gym.gymapp.controller;

import com.gym.gymapp.dto.RegistrationDtos.AddTrainingReq;
import com.gym.gymapp.facade.GymFacade;
import com.gym.gymapp.model.Training;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Api(tags = "Trainings")
@RestController
@RequestMapping("/api/trainings")
public class TrainingController {
    private final GymFacade facade;
    public TrainingController(GymFacade facade) { this.facade = facade; }

    @ApiOperation("Add training")
    @PostMapping
    public ResponseEntity<Void> add(@Valid @RequestBody AddTrainingReq req,
                                    @RequestParam String authUser, @RequestParam String authPass){
        facade.addTraining(authUser, authPass, req.traineeUsername, req.trainerUsername, req.trainingName, null, req.trainingDate, req.durationMinutes);
        return ResponseEntity.ok().build();
    }

    @ApiOperation("Get trainee trainings")
    @GetMapping("/trainee/{username}")
    public ResponseEntity<List<Training>> traineeTrainings(@PathVariable String username,
                                                           @RequestParam String authUser, @RequestParam String authPass,
                                                           @RequestParam(required=false) LocalDate from,
                                                           @RequestParam(required=false) LocalDate to,
                                                           @RequestParam(required=false) String trainerName,
                                                           @RequestParam(required=false) String trainingType){
        return ResponseEntity.ok(facade.getTraineeTrainings(authUser, authPass, username, from, to, trainerName, trainingType));
    }

    @ApiOperation("Get trainer trainings")
    @GetMapping("/trainer/{username}")
    public ResponseEntity<List<Training>> trainerTrainings(@PathVariable String username,
                                                           @RequestParam String authUser, @RequestParam String authPass,
                                                           @RequestParam(required=false) LocalDate from,
                                                           @RequestParam(required=false) LocalDate to,
                                                           @RequestParam(required=false) String traineeName){
        return ResponseEntity.ok(facade.getTrainerTrainings(authUser, authPass, username, from, to, traineeName));
    }
}
