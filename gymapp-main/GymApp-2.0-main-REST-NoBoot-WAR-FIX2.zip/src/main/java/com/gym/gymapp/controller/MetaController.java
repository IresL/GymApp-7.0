package com.gym.gymapp.controller;

import com.gym.gymapp.model.TrainingType;
import com.gym.gymapp.repository.TrainingTypeRepository;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "Meta")
@RestController
@RequestMapping("/api")
public class MetaController {
    private final TrainingTypeRepository repo;
    public MetaController(TrainingTypeRepository repo) { this.repo = repo; }

    @ApiOperation("Get training types")
    @GetMapping("/training-types")
    public ResponseEntity<List<TrainingType>> types(){
        return ResponseEntity.ok(repo.findAll());
    }
}
