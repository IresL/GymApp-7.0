package com.gym.gymapp.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;
import java.util.List;

public class RegistrationDtos {
    public static class TraineeRegisterReq {
        @NotBlank public String firstName;
        @NotBlank public String lastName;
        public LocalDate dateOfBirth;
        public String address;
    }
    public static class TrainerRegisterReq {
        @NotBlank public String firstName;
        @NotBlank public String lastName;
        @NotBlank public String specialization;
    }
    public static class CredentialsResp {
        public String username;
        public String password;
        public CredentialsResp(String u, String p){ this.username=u; this.password=p; }
    }

    public static class ChangePasswordReq {
        @NotBlank public String username;
        @NotBlank public String oldPassword;
        @NotBlank public String newPassword;
    }

    public static class UsernameReq { @NotBlank public String username; }

    public static class UpdateTraineeReq {
        @NotBlank public String username;
        public LocalDate dateOfBirth;
        public String address;
        @NotNull public Boolean isActive;
    }

    public static class UpdateTrainerReq {
        @NotBlank public String username;
        @NotBlank public String firstName;
        @NotBlank public String lastName;
        @NotNull public Boolean isActive;
    }

    public static class UpdateTraineeTrainersReq {
        @NotBlank public String traineeUsername;
        @NotNull public List<@NotBlank String> trainers;
    }

    public static class AddTrainingReq {
        @NotBlank public String traineeUsername;
        @NotBlank public String trainerUsername;
        @NotBlank public String trainingName;
        @NotNull public java.time.LocalDate trainingDate;
        @NotNull public Integer durationMinutes;
    }
}
