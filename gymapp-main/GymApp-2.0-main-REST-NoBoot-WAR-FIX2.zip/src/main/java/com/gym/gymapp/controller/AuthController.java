package com.gym.gymapp.controller;

import com.gym.gymapp.dto.RegistrationDtos.ChangePasswordReq;
import com.gym.gymapp.service.AuthService;
import com.gym.gymapp.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Api(tags = "Auth")
@RestController
@RequestMapping("/api")
public class AuthController {
    private final AuthService authService;
    private final UserService userService;
    public AuthController(AuthService authService, UserService userService) {
        this.authService = authService;
        this.userService = userService;
    }

    @ApiOperation("Login")
    @GetMapping("/login")
    public ResponseEntity<Void> login(@RequestParam String username, @RequestParam String password){
        authService.requireAuth(username, password);
        return ResponseEntity.ok().build();
    }

    @ApiOperation("Change password")
    @PutMapping("/login")
    public ResponseEntity<Void> changePassword(@Valid @RequestBody ChangePasswordReq req){
        userService.changePassword(req.username, req.oldPassword, req.newPassword);
        return ResponseEntity.ok().build();
    }
}
