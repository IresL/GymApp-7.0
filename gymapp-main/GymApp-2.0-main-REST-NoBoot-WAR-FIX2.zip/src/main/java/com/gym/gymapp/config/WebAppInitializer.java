package com.gym.gymapp.config;

import jakarta.servlet.Filter;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;
import com.gym.gymapp.web.RequestLoggingFilter;

public class WebAppInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {
    @Override
    protected Class<?>[] getRootConfigClasses() { return new Class<?>[]{ RootConfig.class }; }

    @Override
    protected Class<?>[] getServletConfigClasses() { return new Class<?>[]{ WebConfig.class }; }

    @Override
    protected String[] getServletMappings() { return new String[]{ "/" }; }

    @Override
    protected Filter[] getServletFilters() { return new Filter[]{ new RequestLoggingFilter() }; }
}
